Overview

    This project creates five visualizations student performance data.
    These visualizations draw attention to patterns in the data that 
    would be difficult to detect simply by poring over the raw data.
    
Data

    The data is provided by the professor via Box, the link to which 
    is found on canvas, in the instructions for this assignment.
    
    The data consists of:
    
        1000 rows
        
        8 columns:
            gender
                male/female
            race/ethnicity
                group A, group B (categories hidden)
            parental level of education
                high school, some college, degree, etc
            lunch subsidy
                standard, "free/reduced"
            test prep course completion
                none/completed
            math score
                0-100
            reading score
                0-100
            writing score
                0-100

Components

    Processing data using pandas
    Various visualizations using pandas and matplotlib.pyplot
    
Output

    Fig 1: bar plot of MEAN SCORE (math, reading, writing, composite) vs PARENT EDUCATION
        to examine potential effect of parental education on performance
    
    Fig 2: boxplot of SCORE vs SUBJECT
        to examine average performance differences between subjects
    
    Fig 3: bar plot of MEAN COMPOSITE SCORE vs GENDER
        to examine performance differences between genders

    Fig 4: bar plot of MATH SCORE vs RACE/ETHNICITY
        to examine performance differences between racial/ethnic groups
    
    Fig 5: Bar plot of COMPOSITE SCORE vs TEST PREP COMPLETION
        to examine potential effect of formal test prep on performance
