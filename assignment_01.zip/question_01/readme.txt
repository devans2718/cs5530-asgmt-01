Overview

    This project investigates the relationship between certain physical traits,
    in particular their relationship with physical 'frailty'. This project is
    written in Python, using standard analysis packages, including Pandas, NumPy,
    and matplotlib.
    
Components

    Processing of raw data
    Analysis of processed data
    Visualization
    Package requirements
    
Installation

    Download and install a recent python version
        Specifically, this project was written with Python 3.12.6
    
    Ensure you have dependencies installed. Open a python terminal and run:
        pip install -r requirements.txt
