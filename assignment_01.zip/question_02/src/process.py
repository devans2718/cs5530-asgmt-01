#%% imports

import pandas as pd
import numpy as np


#%% 
df = pd.read_csv('question_02/data/StudentsPerformance.csv')


#%% check for missing values

exist_na = df.isnull().any(axis=None)


#%% rename columns
df.rename(columns={'race/ethnicity': 'race_ethnicity',
                   'parental level of education': 'parent_education',
                   'test preparation course': 'test_prep',
                   'math score': 'math',
                   'reading score': 'reading',
                   'writing score': 'writing'},
          inplace=True)


#%% compute composite score (mean of all subjects)
def calc_composite_score(row):
    return (row['math'] + row['reading'] + row['writing']) // 3

df['composite'] = df.apply(calc_composite_score, axis=1)


#%% save processed data
df.to_csv('question_02/data/processed.csv', index=False)
