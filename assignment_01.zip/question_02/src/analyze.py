import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

df = pd.read_csv('question_02/data/processed.csv')


# %% Fig 1: bar plot of MEAN SCORE (math, reading, writing, composite) vs PARENT EDUCATION
# suggests a moderate link between performance and parent education
plot_1 = df\
    .groupby('parent_education')[['math', 'reading', 'writing', 'composite']]\
    .mean()\
    .plot(kind='bar', xlim=(0, 100),
          title='Bar Plot of Mean Score (all subjects and composite) vs Parent Education')\
    .legend(bbox_to_anchor=(1, 1), loc='upper left')

plot_1.get_figure().savefig('question_02/visualization/plot_1.png',
                            bbox_inches='tight')

# %% Fig 2: boxplot of SCORE vs SUBJECT
# shows comparable performance between subjects
plot_2 = df[['math', 'reading', 'writing']]\
    .plot(kind='box', title='Boxplot of Scores in Each Subject')

plot_2.get_figure().savefig('question_02/visualization/plot_2.png',
                            bbox_inches='tight')


# %% Fig 3: bar plot of MEAN COMPOSITE SCORE vs GENDER
# shows comparable performance between genders
plot_3 = df\
    .groupby('gender')[['composite']]\
    .mean()\
    .plot(kind='bar',
          title='Bar Plot of Mean Composite Score vs Gender')

plot_3.get_figure().savefig('question_02/visualization/plot_3.png',
                            bbox_inches='tight')


# %% Fig 4: bar plot of MATH SCORE vs RACE/ETHNICITY
# shows apparent differences between racial/ethnic groups
plot_4 = df\
    .groupby('race_ethnicity')[['math']]\
    .mean()\
    .plot(kind='bar',
          title='Bar Plot of Mean Math Score vs Race/Ethnicity')

plot_4.get_figure().savefig('question_02/visualization/plot_4.png',
                            bbox_inches='tight')


# %% Fig 5: Bar plot of COMPOSITE SCORE vs TEST PREP COMPLETION
# suggests moderate link between formal test preparation and lack thereof
plot_5 = df\
    .groupby('test_prep')[['composite']]\
    .mean()\
    .plot(kind='bar',
          title='Bar Plot of Composite Score vs Test Prep Completion')

plot_5.get_figure().savefig('question_02/visualization/plot_5.png')
